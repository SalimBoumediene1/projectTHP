require 'mspec/mocks/mock'
require 'mspec/mocks/proxy'
require 'mspec/mocks/object'
